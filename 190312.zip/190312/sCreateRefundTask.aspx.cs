﻿using System;
using System.Web.UI.HtmlControls;

namespace itemTrades.web.server
{
    public partial class sCreateRefundTask : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HtmlLink link = new HtmlLink();
            link.Attributes.Add("type", "text/css");
            link.Attributes.Add("rel", "stylesheet");
            link.Attributes.Add("href", "/css/server/sCreateRefundTask.css?v=20190222");
            this.Page.Header.Controls.Add(link);

            HtmlGenericControl JsControl = new HtmlGenericControl("script");
            JsControl.Attributes.Add("type", "text/javascript");
            JsControl.Attributes.Add("src", "/javascript/server/sCreateRefundTask.js?v=20190222");
            this.Page.Header.Controls.Add(JsControl);
            this.Page.Header.Title = "发布退款任务";
        }
    }
}