﻿//千人千面 地域范围  
var cityStr = '';
//限制输入充值金额格式
function amountLimit(obj) {
    obj.value = obj.value.replace(/[^\d.]/g, "");
    obj.value = obj.value.replace(/\.{2,}/g, ".");
    obj.value = obj.value.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
    obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');
    if (obj.value.indexOf(".") < 0 && obj.value != "") {
        obj.value = parseFloat(obj.value);
    }
}
//1.商品信息 成交价格显示
function totalMoney() {
    var goodsCount = document.getElementById("goodsCount").value;
    var goodsPrice = document.getElementById("goodsPrice").value;
    var pricePerSpan = document.getElementById("pricePerSpan");
    if (goodsCount == "" || goodsCount == "null") {
        pricePerSpan.innerText = "0.00";
    } else {
        pricePerSpan.innerText = (Number(goodsCount) * Number(goodsPrice)).toFixed(2);
    }
}
//附加商品每单总金额
function addTotalMoney() {
    var addProductList = document.getElementById("addProductList");
    var addGoodsCount = addProductList.querySelectorAll(".goodsCount");
    var addGoodsPrice = addProductList.querySelectorAll(".goodsPrice");
    var pricePerSpan = addProductList.querySelectorAll(".pricePerSpan");
    for (var i = 0; i < addGoodsCount.length; i++) {
        if (addGoodsCount[i].value == "" || addGoodsCount[i].value == "null") {
            pricePerSpan[i].innerText = "0.00";
        } else {
            pricePerSpan[i].innerText = (Number(addGoodsCount[i].value) * Number(addGoodsPrice[i].value)).toFixed(2);
        }
    }
}
//总任务数量显示
function totalTaskNum() {
    var taskCount = document.querySelectorAll("input[name=TaskCount]");
    var totalTaskCount = 0;
    for (var i = 0; i < taskCount.length; i++) {
        totalTaskCount += Number(taskCount[i].value);
    }
    document.getElementById("totalTaskCount").innerText = totalTaskCount;
    countLimit()
}
//赏金输入限制
function rewardInputLimit(_this) {
    var val = Number(_this.value);
    if (val < 1 || val > 50) {
        tipBoxJ.msg({
            title: "请输入1-50之间的数字",
            time: 1000,
            icon: 2
        })
        _this.value = "";
    } else {
        var reg = new RegExp(/^[1-9]{1,2}(\.\d)?$/);
        if (reg.test(val)) {
            return true;
        } else {
            _this.value = "";
            return false;
        }
    }
}
//添加更多附加商品
function addMoreProductInfo() {
    //最多可以添加2个  超出提示
    var count = document.getElementById("addProductList").querySelectorAll("li").length + 1;
    document.querySelectorAll(".auxiliaryTipBlock")[0].style.borderBottom = "1px solid #c7c7c7";
    if (count > 2) {
        tipBoxJ.msg({ title: "最多只能添加2个商品信息", time: 1000, icon: 2 });
        return;
    }
    var str = ' <li class="productLi">'
        + ' <div style = "margin: 15px;"  class="auxiliaryBlock" >'
        + ' <div>'
        + '<label>商品名称：</label>'
        + '<input type="text" style="margin-left: 1px;"  class="txtShopNameInput goodsName" />'
        + '</div>'
        + '<div style="margin-top: 15px;">'
        + '<label>商品链接：</label>'
        + '<input type="text" style="margin-left: 1px;"  class="txtShopNameInput goodsUrl" />'
        + '</div>'
        + '<div class="shopSetDiv">'
        + '<div class="moneySetInnerDiv">'
        + '<label style="float: left;">成交价格：</label>'
        + '<div class="PriceInputInnerDiv">'
        + ' <input type="text"  class="miniInput actualInput goodsPrice" onkeyup="amountLimit(this)" data-index="0" onblur="addTotalMoney()" />'
        + '  <span>元</span>'
        + ' </div>'
        + ' <span class="LongShopTip">( 每单总金额<span class="pricePerSpan">0</span>元(不含运费)）</span>'
        + ' </div>'
        + '  <div class="moneySetInnerDiv">'
        + '  <label style="float: left;">展示价格：</label>'
        + '   <div class="PriceInputInnerDiv">'
        + '    <input type="text"  class="miniInput displayInput goodsDisplayPrice" onkeyup="amountLimit(this)" />'
        + '    <span>元</span>'
        + '   </div>'
        + '  <span class="LongShopTip">( 务必亲自在手机端搜索，保证价格准确 )</span>'
        + '  </div>'
        + ' </div>'
        + '   <div class="shopSetDiv">'
        + '   <div class="moneySetInnerDiv">'
        + '     <label style="float: left;">单拍数量：</label>'
        + '   <div class="PriceInputInnerDiv">'
        + '    <input type="text" class="miniInput pernumInput goodsCount" onkeyup="intNum(this)" data-index="0" onblur="addTotalMoney()" />'
        + '   <span>件</span>'
        + '   </div>'
        + '  <span class="LongShopTip">( 用户拍下价格,不同等级卖号看到商品价格不同,取最大值 )</span>'
        + '   </div>'
        //+ '   <div class="moneySetInnerDiv">'
        //+ '    <label style="float: left;">商品邮费：</label>'
        //+ '   <div class="PriceInputInnerDiv">'
        //+ '  <input type="text" id="" class="miniInput postInput postagePrice" onkeyup="amountLimit(this)" />'
        //+ '   <span>元</span>'
        //+ ' </div>'
        //+ '  <span class="LongShopTip">( 如订单拍下需邮费,则按邮费金额填写,如邮费是0也可不用填写 )</span>'
        //+ '  </div>'
        + '  </div>'
        + '   <div style="margin-top: 15px;">'
        + '    <label style="float: left; line-height: 23px">商品属性：</label>'
        + '   <div class="shopPropertyDiv" id="">'
        + '  <input type="text"  placeholder="尺码" class="txtSizeInput skuValue" />'
        + ' <span class="LongShopTip">( 多个属性请用";"分隔 )</span>'
        + ' </div>'
        + '</div>'
        + '  <div style="margin-top: 20px;" data-value="imgList" id="">'
        + '   <label style="float: left">商品主图：</label>'

        + ' <div style="display: inline-block; float: left" class="addImgBack">'
        + '  <div class="imgBackNull">'
        + '  <img src="/img/Program/null.jpg" class="imgUploadStyle" />'
        + '  </div>'
        + '  </div>'
        + '   <div class="addDiv">'
        + '  <span class="btnAddImg" onclick="uploadImg(this)">+</span>'
        + '  <input type="file" id="" class="btnFile" accept="image/gif,image/jpeg,image/jpg,image/png,image/bmp" data-id="imgList" onchange="uploadImg(this)" />'
        + '  </div>'
        + '  <button type="button" class="btnDeleteAddProduct" onclick="deleteAddProduct(this)"><img src="/img/Program/del.png" style="width:27px"></button>'

        + '  </div>'

        + ' </div></li >';
    document.getElementById("addProductList").insertAdjacentHTML("beforeend", str);
}
//删除附加商品
function deleteAddProduct(_this) {
    var targetNode = _this.parentNode.parentNode.parentNode;
    document.getElementById("addProductList").removeChild(targetNode);
    var addProductList_li = document.getElementById("addProductList").querySelectorAll("li");
    if (addProductList_li.length == 0) {
        document.querySelectorAll(".auxiliaryTipBlock")[0].style.borderBottom = "none";
    }
}
//获取省
function getProvince() {
    var data = {
        ProvinceCode: null,
        CityCode: null,
        DistrictCode: null
    };
    tipBoxJ.loadNew();
    SubmitData("/api/server/getDomesticCity", "POST", data, false, function (e) {
        if (e != null && isJsonString(e)) {
            tipBoxJ.closeNew();
            var res = JSON.parse(e);
            var data = res.rData.CityList;
            var str = '<option value="">全国</option>';
            var _provinceName = "";
            var cityName = "";
            if (res.rCode == "0000") {
                for (var i = 0; i < data.length; i++) {
                    var _provinceCode = data[i].ProvinceCode,
                        _provinceName = data[i].ProvinceName;
                    str += '<option value="' + _provinceCode + '">' + _provinceName + '</option>';
                }
                document.getElementById("address_select").innerHTML = str;
                //千人千面  ----地域范围
                var areaRange = document.getElementById("areaRange");//获取千人千面 地域范围div
                var cityLen = data.length;

                for (var j = 0; j < cityLen; j++) {
                    //将后缀去掉
                    _provinceName = data[j].ProvinceName;
                    var _provinceCode = data[j].ProvinceCode;

                    if (_provinceName.indexOf("市") > 0) {
                        cityName = _provinceName.replace("市", "");
                    }
                    if (_provinceName.indexOf("省") > 0) {
                        cityName = _provinceName.replace("省", "");
                    }
                    if (_provinceName.indexOf("壮族自治区") > 0) {
                        cityName = _provinceName.replace("壮族自治区", "");
                    }
                    if (_provinceName.indexOf("回族自治区") > 0) {
                        cityName = _provinceName.replace("回族自治区", "");
                    }
                    if (_provinceName.indexOf("自治区") > 0 && _provinceCode == "540000000000") {
                        cityName = _provinceName.replace("西藏自治区", "西藏");
                    }
                    if (_provinceName.indexOf("自治区") > 0 && _provinceCode == "150000000000") {
                        cityName = _provinceName.replace("内蒙古自治区", "内蒙古");
                    } if (_provinceName.indexOf("维吾尔自治区") > 0) {
                        cityName = _provinceName.replace("维吾尔自治区", "");
                    }
                    cityStr += '<label class="cityLabel"><input type = "checkbox" name = "city" value = "' + _provinceName + '" />' + cityName + '</label >';
                }
            } else if (res.rCode == '0001' || res.rCode == "0002") {
                tipBoxJ.msg({
                    title: res.rMsg,
                    time: 1000,
                    icon: 2
                })
            } else {
                tipBoxJ.msg({
                    title: res.rMsg,
                    time: 1000,
                    icon: 2
                })
            }
        }
    }, function (readyState, Status) { })
}
//显示与隐藏好评任务
function isShowTask(_this) {
    var browse = document.getElementById("browseTaskKeywordList");
    var text = document.getElementById("payTaskKeywordList");
    var img = document.getElementById("imgTaskKeywordList");
    var textCheckBox = document.getElementById("textCheckBox");
    var normalCheckBox = document.getElementById("normalCheckBox");
    var ImgtextCheckBox = document.getElementById("ImgtextCheckBox");
    var addTaskBtn = document.getElementsByClassName(".addTaskBtnBlock");
    var addBtnList = document.querySelectorAll(".addTaskBtnBlock");
    var browseCheckBox = document.getElementById("browseCheckBox");
    var look = document.getElementById("browseTaskList");
    if (browseCheckBox.checked) {
        look.style.display = "block";
        addBtnList[0].style.display = "inline-block";
    } else {
        look.style.display = "none";
        addBtnList[0].style.display = "none";

    }
    //之前的任务类型
    //if (normalCheckBox.checked) {
    //    browse.style.display = "block";
    //    addBtnList[0].style.display = "inline-block";
    //} else {
    //    browse.style.display = "none";
    //    addBtnList[0].style.display = "none";

    //}
    //if (textCheckBox.checked) {
    //    text.style.display = "block";
    //    addBtnList[1].style.display = "inline-block";
    //} else {
    //    text.style.display = "none";
    //    addBtnList[1].style.display = "none";

    //}
    //if (ImgtextCheckBox.checked) {
    //    img.style.display = "block";
    //    addBtnList[2].style.display = "inline-block";
    //} else {
    //    img.style.display = "none";
    //    addBtnList[2].style.display = "none";

    //}


}
//添加更多退款任务
function addMoreBrowseTask() {
    var count = document.getElementById("browseTaskList").querySelectorAll("li").length + 1;
    if (count > 99) {
        tipBoxJ.msg({ title: "最多添加99条普通好评任务说明", time: 1000, icon: 2 });
        return;
    }
    var str = '<li class="browseLi">'
        + '  <span style = "margin-left: 15px;" > 搜索关键字<span class="browseTaskCount">' + count + '</span>：</span> <input type="text" value="" class="searchBigInput" name="GoodsKeywords" /> <span style="margin-left: 10px;">数量：</span> <input type="number" class="minInput" name="TaskCount" style="width: 60px;margin-left: -5px;" min="1" oninput="if(value.length>5)value=value.slice(0,5);intNum(this)" onkeyup="intNum(this)" onchange="totalTaskNum()" />'
        + '<button type="button" class="btnDeleteBrowse" onclick="deleteBrowseTask(this)"><img src="/img/Program/del.png" style="width:27px"></button>'
        + '  <div class="addRefundTaskBrowseType clearFix">'
        + '  <span style="margin-left:15px;float:left;">附加：</span>'
        + '  <div class="taskBrowseTypeLabel">'
        + '    <label><input type="checkbox" name="CollectionGoods" data-price="0.5" class="addTask" value="收藏商品" />收藏商品<span>（0.5元/单）</span></label>'
        + '    <label><input type="checkbox" name="CollectionShop" data-price="0.6" class="addTask" value="收藏店铺" />收藏店铺<span>（0.6元/单）</span></label>'
        + '   <label><input type="checkbox" name="ShoppingCart" data-price="0.8" class="addTask"  value="加购物车" />加购物车<span>（0.8元/单）</span></label>'
        + '</div>'
        + '  </div></li >';
    document.getElementById("browseTaskList").insertAdjacentHTML("beforeend", str);

}
//删除退款任务
function deleteBrowseTask(_this) {
    var count = document.getElementById("browseTaskList").querySelectorAll(".browseTaskCount");
    var this_li = _this.parentNode;
    var keyCode_span = this_li.querySelector(".browseTaskCount");
    var keyCode = Number(keyCode_span.innerText) - 1;
    var len = count.length;
    for (var i = keyCode; i < len; i++) {
        count[i].innerHTML = i + 1;
    }
    document.getElementById("browseTaskList").removeChild(this_li);
    totalTaskNum();
}
//添加更多普通好评任务
function addMoreBrowseTaskKeywordList() {
    var count = document.getElementById("browseTaskKeywordList").querySelectorAll("li").length + 1;
    if (count > 99) {
        tipBoxJ.msg({ title: "最多添加99条普通好评任务说明", time: 1000, icon: 2 });
        return;
    }
    var str = '<li class="browseLi"><span style="margin-left:15px;">搜索关键字<span class="browseTaskKeywordCount">' + count + '</span>：</span>'
        + '<input type="text" value="" class="searchBigInput" name="GoodsKeywords" />'
        + '<span style="margin-left: 15px;">数量：</span>'
        + '<input type="number" value="" class="minInput" name="TaskCount" style="width: 60px;" oninput="if(value.length>5)value=value.slice(0,5);intNum(this)" onkeyup="intNum(this)" onchange="calculateAllNum()"/>'
        + '<button type="button" class="btnDeleteBrowse" onclick="deleteBrowseTaskKeywords(this)"><img src="/img/Program/del.png" style="width:27px"></button></li>';
    document.getElementById("browseTaskKeywordList").insertAdjacentHTML("beforeend", str);
}
//删除普通好评任务
function deleteBrowseTaskKeywords(_this) {
    var count = document.getElementById("browseTaskKeywordList").querySelectorAll(".browseTaskKeywordCount");
    var this_li = _this.parentNode;
    var keyCode_span = this_li.querySelectorAll(".browseTaskKeywordCount");
    var keyCode = Number(keyCode_span[0].innerText) - 1;
    var len = count.length;
    for (var i = keyCode; i < len; i++) {
        count[i].innerHTML = i + 1;
    }
    document.getElementById("browseTaskKeywordList").removeChild(this_li);
    //calculateAllNum();
}
//添加更多文字好评任务
function addMoreTextTaskKeywordList() {
    var count = document.getElementById("payTaskKeywordList").querySelectorAll("li").length + 1;
    if (count > 99) {
        tipBoxJ.msg({ title: "最多添加99条文字好评任务说明", time: 1000, icon: 2 });
        return;
    }
    var str = '<li class="browseLi"><span style="margin-left: 15px;">搜索关键字<span class="textTaskKeywordCount">' + count + '</span>：</span><input type="text" value="" class="searchBigInput" name="GoodsKeywords" />'
        + ' <span style = "margin-left: 15px;" > 数量：</span> <input type="number" value="1" class="minInput" name="TaskCount" style="width: 60px;" oninput="if(value.length>5)value=value.slice(0,5);intNum(this)" onkeyup="intNum(this)" onchange="calculateAllNum()" disabled />'
        + '  <span class="searchDangerTip">注意：当同一个搜索关键字【添加订单】超过两单,可能会造成评价重复的情况,请知悉。如有疑问,请联系客服。</span>'
        + '  <button type="button" class="btnDeleteBrowse" onclick="deleteGoodReputationList(this)"><img src="/img/Program/del.png" style="width:27px"></button>'
        + ' <div style="margin: 15px"><label style="float: left">文字好评内容：</label>'
        + ' <textarea class="goodReputationArea" maxlength="200" name="textGoodReputation" onblur="this.value=stripscript(this.value);"></textarea></div></li > ';
    document.getElementById("payTaskKeywordList").insertAdjacentHTML("beforeend", str);
}
//删除文字好评任务
function deleteGoodReputationList(_this) {
    //循坏当前ul中所有li 用下标来确定
    var count = document.getElementById("payTaskKeywordList").querySelectorAll(".textTaskKeywordCount");//关键字span
    var this_li = _this.parentNode;
    var keyCode_span = this_li.querySelectorAll(".textTaskKeywordCount");
    var keyCode = Number(keyCode_span[0].innerText) - 1;
    for (var i = keyCode; i < count.length; i++) {
        count[i].innerHTML = i + 1;
    }
    document.getElementById("payTaskKeywordList").removeChild(this_li);
    //calculateAllNum(); 

}
//添加更多 图文好评任务
function addMoreImgTaskKeywordList() {
    var ul = document.getElementById("imgTaskKeywordList");
    var count = ul.querySelectorAll("li").length + 1;
    if (count > 99) {
        tipBoxJ.msg({ title: "最多添加99条图文好评任务说明", time: 1000, icon: 2 });
        return;
    }
    var str = '<li class="browseLi">'
        + ' <span style = "margin-left: 15px;"> 搜索关键字<span class="imgTaskKeywordCount">' + count + '</span>:</span>'
        + ' <input type="text" value="" class="searchBigInput" name="GoodsKeywords" /> '
        + '  <span style="margin-left: 15px;">数量：</span> '
        + '  <input type="number" value="1" class="minInput" name="TaskCount" style="width: 60px;" oninput="if(value.length>5)value=value.slice(0,5);intNum(this)" onkeyup="intNum(this)" onchange="calculateAllNum()" disabled />'
        + '  <button type="button" class="btnDeleteBrowse" onclick="deleteImgTaskKeywordList(this)"><img src="/img/Program/del.png" style="width:27px"></button>'
        + '  <div style="margin:15px;">'
        + '    <label style="float:left;">上传图片：</label>'
        + '      <div class="imgUploadGoodreputaionBlock" style="display: inline-block; float: left; margin-left: 15px">'
        + '         <div class="imgBackNull">'
        + '              <img src="/img/Program/null.jpg" class="imgUploadStyle" />'
        + '        </div>'
        + '    </div>'
        + '     <div class="addDiv">'
        + '         <span class="btnAddImg" onclick="uploadImg(this)">+</span>'
        + '       <input type="file" class="btnFile" accept="image/gif,image/jpeg,image/jpg,image/png,image/bmp" data-id="imgList" onchange="uploadImg(this)" />'
        + '  </div>'
        + '  </div>'
        + '  <div style="margin: 15px">'
        + '    <label style="float: left">文字好评内容：</label>'
        + '    <textarea class="goodReputationArea" maxlength="200" name="textGoodReputation" onblur="this.value=stripscript(this.value);"></textarea> </li>';
    ul.insertAdjacentHTML("beforeend", str);
}
//删除图文好评任务
function deleteImgTaskKeywordList(_this) {
    var count = document.getElementById("imgTaskKeywordList").querySelectorAll(".imgTaskKeywordCount");
    var val = _this.parentNode.querySelector(".imgTaskKeywordCount").innerText;
    var index = Number(val) - 1;
    var len = count.length;
    for (var i = index; i < len; i++) {
        //删除之后改变数字
        count[i].innerHTML = i + 1;
    }
    document.getElementById("imgTaskKeywordList").removeChild(_this.parentNode);

}
//切换推送设置的时间提示方式
function changePushWay(_this) {
    //显示与隐藏
    // 默认隐藏  当被选中的时候显示   点击另外一个隐藏
    if (_this.checked) {
        document.getElementById("pushTimerList").style.display = "block";
    } else {
        document.getElementById("pushTimerList").style.display = "none";
    }
    totalTaskNum()
}
function changePushAll(_this) {
    if (_this.checked == true) {
        document.getElementById("pushTimerList").style.display = "none";
    } else {
        document.getElementById("pushTimerList").style.display = "block";
    }
}
//选择更多的推送时间点 --推送设置
function addMorePushSetTime() {
    var str = '<li class="pushTimerLi">'
        + '<span style="margin-left: 5px;">时间点：</span><input type="number" value="" class="middleInput" name="pushTimer" min="1" max="23" onblur="pushTimerTest(this)"/>'
        + '<span style = "margin-left: 15px;" > 数量：</span> <input type="number" class="middleInput" name="pushCount" min="1" oninput="countLimit(this)" onblur="countLimit(this)" onkeyup="intNum(this)"/>'
        + '<button type="button" class="btnDeleteBrowse" onclick="deletePushTimer(this)"><img src="/img/Program/del.png" style="width:27px"></button>'
        + '</li>';
    document.getElementById("pushTimerList").insertAdjacentHTML("beforeend", str);

}
//删除推送时间点
function deletePushTimer(_this) {
    document.getElementById("pushTimerList").removeChild(_this.parentNode);
}
//关于推送时间点的验证
function pushTimerTest(_this) {
    if (parseInt(_this.value) == _this.value && parseInt(_this.value) >= 0 && parseInt(_this.value) <= 23) {
        return true
    } else {
        tipBoxJ.msg({
            title: "请输入正确的时间格式",
            time: 1000,
            icon: 2
        })
        _this.value = "";
    }

}
//上传图片 
function uploadImg(obj) {
    //obj.value  当前选中的图片
    //obj.files   当前选择的图片列表
    //imgBack 显示图片的div   imgBackNul 未选择图片的状态
    var obj_id = obj.parentNode.parentNode.id;
    var imgBox = obj.parentNode.previousElementSibling; //存放图片的div
    var imgBack = imgBox.querySelectorAll(".imgBack");//真正图片展示div
    //限制图片数量
    if (obj_id == "imgList") {//商品主图
        if (imgBack.length > 1) {
            tipBoxJ.msg({ title: "最多只能上传两张照片", time: 1000, icon: 2 });
            return false;
        }
    } else {
        if (imgBack.length > 2) {//附加要求
            tipBoxJ.msg({ title: "最多只能上传三张照片", time: 1000, icon: 2 });
            return false;
        }
    }
    if (obj.value == "" || obj.value == null) {
        tipBoxJ.msg({ title: "没有选择文件", time: 1000, icon: 2 });
        return false;
    }
    //判断图片后缀
    var ext = obj.value.substring(obj.value.lastIndexOf(".") + 1).toLowerCase();

    if (ext != 'png' && ext != 'jpg' && ext != 'jpeg' && ext != 'gif' && ext != 'bmp') {
        tipBoxJ.msg({ title: "图片的格式必须为png、jpg、jpeg、bmp及gif格式！", time: 1000, icon: 2 });
        return false;
    }
    if (obj.value != null && obj.files.length > 0) {
        tipBoxJ.loadNew();
        var formData = new FormData();
        formData.append("FileCode", "");
        formData.append("FileType", "12");//图片指定路径

        //限制图片大小
        for (var i = 0; i < obj.files.length; i++) {
            var size = obj.files[i].size / 1024 / 1024;
            if (size > 5) {
                tipBoxJ.closeNew();
                tipBoxJ.msg({ title: "上传的图片大小不能超过5M！", time: 1000 });
                return false;
            }
            formData.append("File[" + i + "]", obj.files[i]);
        }
        //上传图片
        uploadFile("/api/server/uploadFile", "POST", formData, true, function (e) {
            var res = JSON.parse(e);
            var files = res.rData.Files;
            var imgUrl = '';
            if (res.rCode == "0000") {
                tipBoxJ.closeNew();
                for (var i = 0; i < files.length; i++) {
                    imgUrl = files[i].FileUrl;
                    var imgStr = '<div class="imgBack" id="imgBack">'
                        + ' <span class="removeIcon" id = "removeIcon" onclick = "removeImg(this)" > '
                        + '  <a class="removeInnerIcon" > x</a ></span > '
                        + '<img src = "' + imgUrl + '" class="imgUploadStyle"></div>';
                    if (imgBack.length < 1) {
                        imgBox.innerHTML = " ";
                    }
                }
                imgBox.innerHTML += imgStr;
            } else {
                tipBoxJ.closeNew();
                tipBoxJ.msg({ title: res.rMsg, time: 1000, icon: 2 });
            }
        }, function (readyState, Status) {
            tipBoxJ.closeNew();
        })
    }
}
//删除图片
function removeImg(_this) {
    //删除图片所在区域，并将未选中的初始图片放上去
    //删除图片 ----    一张或多张的情况   一张的时候，删除后显示空图片   多张的时候 删除照片框中的一张
    var imgBox = _this.parentNode.parentNode;
    var imgBack = imgBox.querySelectorAll(".imgBack");
    if (imgBack.length == 1) {
        var str = '<div class="imgBackNull" id="imgBackNull"><img src = "/img/Program/null.jpg" class="imgUploadStyle" /></div >';
        imgBox.innerHTML = str;
    } else {
        imgBox.removeChild(_this.parentNode);
    }
}
//不同平台搜索商品条件的服务展示(淘宝/京东)
function showPlatformService() {
    var plan_id = GetQueryString("PLANID");//得到平台类型
    var str = '';
    if (plan_id == "taobao") {
        str = '<label style="float: left;">折扣与服务：</label>'
            + '<label><input type="checkbox" value="包邮" /><span class="tagSpan">包邮</span></label>'
            + '<label><input type="checkbox" value="天猫" /><span class="tagSpan">天猫</span></label>'
            + '<label><input type="checkbox" value="淘金币" /><span class="tagSpan">淘金币</span></label>'
            + '<label><input type="checkbox" value="货到付款" /><span class="tagSpan">货到付款</span></label>'
            + '<label><input type="checkbox" value="消费者保障" /><span class="tagSpan">消费者保障</span></label>'
            + '<label><input type="checkbox" value="赠送运费险" /><span class="tagSpan">赠送运费险</span></label>'
            + '<label><input type="checkbox" value="7+天退换货" /><span class="tagSpan">7+天退换货</span></label>'
            + '<label><input type="checkbox" value="天猫国际" /><span class="tagSpan">天猫国际</span></label>'
            + '<label><input type="checkbox" value="全球购" /><span class="tagSpan">全球购</span></label>'
            + '<label><input type="checkbox" value="花呗分期" /><span class="tagSpan">花呗分期</span></label>'
            + '<label><input type="checkbox" value="通用排序" /><span class="tagSpan">通用排序</span></label>';
    } else {
        str = '<label style="float: left;">京东服务：</label>'
            + '<label><input type="checkbox" value="京东物流" /><span class="tagSpan">京东物流</span></label>'
            + '<label><input type="checkbox" value="货到付款" /><span class="tagSpan">货到付款</span></label>'
            + '<label><input type="checkbox" value="PLUS专享价" /><span class="tagSpan">PLUS专享价</span></label>'
            + '<label><input type="checkbox" value="促销" /><span class="tagSpan">促销</span></label>'
            + '<label><input type="checkbox" value="全球购" /><span class="tagSpan">全球购</span></label>'
            + '<label><input type="checkbox" value="配送全球" /><span class="tagSpan">配送全球</span></label>';
    }
    document.getElementById("discountInnerDiv").innerHTML = str;
}
//千人千面设置面板
function showOtherSet() {
    //获取设置列表
    var otherSetList = document.getElementById("otherSetList");
    var arrowIcon = document.getElementById("arrowIcon");
    var plan_id = GetQueryString("PLANID");
    if (otherSetList.style.display == "none") {
        var data = {
            PlanID: plan_id
        };
        tipBoxJ.loadNew();
        SubmitData("/api/server/getIncrementService", "POST", data, false, function (e) {
            tipBoxJ.closeNew();
            if (e != null) {
                var res = JSON.parse(e);
                var otherStr = '';
                otherSetList.style.display = "block";
                arrowIcon.style.webkitTransform = 'rotate(90deg)';
                arrowIcon.style.mozTransform = 'rotate(90deg)';
                arrowIcon.style.msTransform = 'rotate(90deg)';
                arrowIcon.style.oTransform = 'rotate(90deg)';
                arrowIcon.style.transform = 'rotate(90deg)';
                //成功
                if (res.rCode == "0000") {
                    cityStr = '';
                    var data = res.rData.IncrementServices;
                    var len = data.length;
                    for (var i = 0; i < len; i++) {
                        if (data[i].ServiceType == 0) {
                            //花呗
                            otherStr += '<li class="otherSetLi"><label ><input type="checkbox"  value="' + data[i].ServiceID + '" id="' + data[i].ServiceID + '" /><span>' + data[i].ServiceName + '</span></label ><span class="otherSetTip">（' + data[i].Description + ',+' + data[i].SPrice + '金/单)</span></li >';
                        } else if (data[i].ServiceType == 2) {
                            //类目
                            var keyStr = '';
                            var keyArr = data[i].ServiceKeys.split(";");
                            for (var j = 0; j < keyArr.length - 1; j++) {
                                keyStr += '<label class="commomLabel"><input type = "checkbox" name = "Category" value = "' + keyArr[j] + '" />' + keyArr[j] + '</label >';
                            }
                            otherStr += '<li class="otherSetLi"><label ><input type="checkbox" onchange="openCategory(this)" value="' + data[i].ServiceID + '" id="' + data[i].ServiceID + '" /><span>' + data[i].ServiceName + '</span></label ><span class="otherSetTip">（' + data[i].Description + ',+' + data[i].SPrice + '金/单)</span></li >'
                                + '<div id="Category" style="margin-top:5px;display:none;margin-left:15px;">' + keyStr + '</div>';

                        } else if (data[i].ServiceType == 1) {
                            //年龄
                            var ageStr = "";
                            var ageArr = data[i].ServiceKeys.split(";");
                            for (var k = 0; k < ageArr.length - 1; k++) {
                                ageStr += ' <label class="ageLabel"><input type = "radio" name = "age" value = "' + ageArr[k] + '"  />' + ageArr[k] + '</label >';
                            }
                            otherStr += '<li class="otherSetLi"><label ><input type="checkbox" onchange="openAge(this)"  value="' + data[i].ServiceID + '" id="' + data[i].ServiceID + '" /><span>' + data[i].ServiceName + '</span></label ><span class="otherSetTip">（' + data[i].Description + ',+' + data[i].SPrice + '金/单)</span></li >'
                                + '<div id="age" style="display:none;margin-top:5px;margin-left:15px;">' + ageStr + '</div>';
                        }
                    }
                    //性别选项
                    var sexStr = '<li class="otherSetLi"><label ><input type="checkbox" id="Sex" value="" onchange="openSex(this)" /><span>性别</span></label ><span class="otherSetTip">（限制性别，+1金/单）</span><div id="sex" style="display:none;margin-top:5px;">'
                        + '<label class="ageLabel"><input type="radio" name="sex" value="男" checked />男 </label><label class="ageLabel"> <input type="radio" name="sex" value="女" />女 </label></div> </li >';
                    otherStr += sexStr;
                    //买号等级
                    if (plan_id == "taobao") {
                        otherStr += '<li class="otherSetLi"><label><input type="checkbox" id="grade" /><span>买号等级</span></label>'
                            + '<span class="otherSetTip">（钻石以上等级可接该任务,+1金/单）</span></li>';
                    } else {
                        otherStr += '<li class="otherSetLi"><label><input type="checkbox" id="grade" /><span>买号等级</span></label>'
                            + '<span class="otherSetTip">（金牌会员以上等级可接该任务,+1金/单）</span></li>';
                    }

                    document.getElementById("otherSetList").innerHTML = otherStr;
                    //地域范围
                    getProvince();
                    var areaStr = '<li class="otherSetLi"><label ><input type="checkbox" id="AreaRange" value="" onchange="openAreaRange(this)" /><span>地域范围</span></label ><span class="otherSetTip">（勾选后可接该任务,+1金/单）</span>'
                        + ' <div id="areaRange" style="margin-top:5px;display:none;">' + cityStr + '</div></li>';
                    document.getElementById("otherSetList").innerHTML = otherStr + areaStr;
                    cityStr = '';
                } else if (res.rCode == "0001" || res.rCode == "0002") {
                    tipBoxJ.msg({
                        title: res.rMsg, time: "1000", icon: 2, callBack: function () {
                            window.location.href = "/web/server/sLogin.aspx";
                        }
                    });
                } else {
                    tipBoxJ.msg({ title: res.rMsg, time: 1000, icon: 2 });
                }
            }
        }, function (readyState, Status) { })
    } else {
        otherSetList.style.display = "none";
        otherSetList.innerHTML = "";
        arrowIcon.style.webkitTransform = 'rotate(0deg)';
        arrowIcon.style.mozTransform = 'rotate(0deg)';
        arrowIcon.style.msTransform = 'rotate(0deg)';
        arrowIcon.style.oTransform = 'rotate(0deg)';
        arrowIcon.style.transform = 'rotate(0deg)';
    }
}
//显示千人千面设置选项 ---类目
function openCategory(_this) {
    if (_this.checked) {
        document.getElementById("Category").style.display = "block";
    } else {
        document.getElementById("Category").style.display = "none";
    }
}
//显示千人千面设置选项 ---年龄
function openAge(_this) {
    if (_this.checked) {
        document.getElementById("age").style.display = "block";
        document.querySelectorAll('input[name=age]')[0].checked = true;
    } else {
        document.getElementById("age").style.display = "none";
        document.querySelectorAll('input[name=age]')[0].checked = false;
    }
}
//显示千人千面设置选项 ---性别
function openSex(_this) {
    if (_this.checked) {
        document.getElementById("sex").style.display = "block";
    } else {
        document.getElementById("sex").style.display = "none";
    }
}
//显示千人千面设置选项 ---地域范围
function openAreaRange(_this) {
    if (_this.checked) {
        document.getElementById("areaRange").style.display = "block";
    } else {
        document.getElementById("areaRange").style.display = "none";
    }
}
//判断必填项
function isRequired() {
    var goodsName = document.getElementById("goodsName").value;
    var goodsUrl = document.getElementById("goodsUrl").value;
    var goodsPrice = document.getElementById("goodsPrice").value;
    var goodsDisplayPrice = document.getElementById("goodsDisplayPrice").value;
    var goodsCount = document.getElementById("goodsCount").value;
    var beginTime = document.getElementById("beginTime").value;
    var imgBackNull = document.getElementById("imgBackNull");
    var browseCheckBox = document.getElementById("browseCheckBox");
    var browseTask_li = document.getElementById("browseTaskList").querySelectorAll("li");//浏览任务
    var pointTime = document.getElementById("pointTime");//推送时间点
    var pushTimerLi = document.querySelectorAll(".pushTimerLi");
    var otherSetList_ul = document.getElementById("otherSetList");//千人千面ul
    var otherSetList_li = otherSetList_ul.querySelectorAll("li");
    var planId = GetQueryString("PLANID");//平台id
    //附加商品 
    var addProductList = document.getElementById("addProductList");// 附加商品ul
    var attachGoodsName = addProductList.querySelectorAll(".goodsName");
    var attachGoodsUrl = addProductList.querySelectorAll(".goodsUrl");
    var attachGoodsPrice = addProductList.querySelectorAll(".goodsPrice");
    var attachGoodsDisplayPrice = addProductList.querySelectorAll(".goodsDisplayPrice");
    var attachGoodsCount = addProductList.querySelectorAll(".goodsCount");
    var attachGoodsImg = addProductList.querySelectorAll(".imgBackNull");
    var assignDay = document.getElementById("assignDay");
    var refundTimes = document.getElementById("refundTimes").value;
    var refundType_select = document.getElementById("refundType_select");
    if (goodsName == "" || goodsName == "null") {
        tipBoxJ.msg({ title: "请输入商品名称", time: 1000, icon: 2 });
        window.location.href = "#goodsName";
        return false
    }
    if (goodsUrl == "" || goodsUrl == "null") {
        tipBoxJ.msg({ title: "请输入商品链接", time: 1000, icon: 2 });
        window.location.href = "#goodsUrl";
        return false
    }
    if (goodsPrice == "" || goodsPrice == "null") {
        tipBoxJ.msg({ title: "请输入成交价格", time: 1000, icon: 2 });
        window.location.href = "#goodsPrice";
        return false
    }
    if (goodsDisplayPrice == "" || goodsDisplayPrice == "null") {
        tipBoxJ.msg({ title: "请输入展示价格", time: 1000, icon: 2 });
        window.location.href = "#goodsDisplayPrice";
        return false
    }
    if (goodsCount == "" || goodsCount == "null") {
        tipBoxJ.msg({ title: "请输入单拍数量", time: 1000, icon: 2 });
        window.location.href = "#goodsCount";
        return false
    }
    //商品主图必须上传一张
    if (imgBackNull) {
        tipBoxJ.msg({ title: "请至少上传一张商品主图", time: 1000, icon: 2 });
        window.location.href = "#editTaskInfo";
        return false
    }

    //附加商品 必填项
    for (var i = 0; i < attachGoodsName.length; i++) {
        if (attachGoodsName[i].value == "" || attachGoodsName[i].value == "null") {
            tipBoxJ.msg({
                title: "请填写附加商品名字",
                time: 1000,
                icon: 2
            })
            location.href = "#addProductList";
            return false;
        }

    }
    for (var i = 0; i < attachGoodsUrl.length; i++) {
        if (attachGoodsUrl[i].value == "" || attachGoodsUrl[i].value == "null") {
            tipBoxJ.msg({
                title: "请填写附加商品链接",
                time: 1000,
                icon: 2
            })
            location.href = "#addProductList";
            return false;
        }

    }
    for (var i = 0; i < attachGoodsPrice.length; i++) {
        if (attachGoodsPrice[i].value == "" || attachGoodsPrice[i].value == "null") {
            tipBoxJ.msg({
                title: "请填写附加商品成交价格",
                time: 1000,
                icon: 2
            })
            location.href = "#addProductList";
            return false;
        }
    }
    for (var i = 0; i < attachGoodsDisplayPrice.length; i++) {
        if (attachGoodsDisplayPrice[i].value == "" || attachGoodsDisplayPrice[i].value == "null") {
            tipBoxJ.msg({
                title: "请填写附加商品展示价格",
                time: 1000,
                icon: 2
            })
            location.href = "#addProductList";
            return false;
        }
    }
    for (var i = 0; i < attachGoodsCount.length; i++) {
        if (attachGoodsCount[i].value == "" || attachGoodsCount[i].value == "null") {
            tipBoxJ.msg({
                title: "请填写附加商品数量",
                time: 1000,
                icon: 2
            })
            location.href = "#addProductList";
            return false;
        }
    }
    for (var i = 0; i < attachGoodsImg.length; i++) {
        if (attachGoodsImg[i]) {
            tipBoxJ.msg({
                title: "请至少选择一张附加商品主图",
                time: 1000,
                icon: 2
            })
            location.href = "#addProductList";
            return false;
        }
    }
    //填写任务类型与数量
    if (browseCheckBox.checked) {
        for (var i = 0; i < browseTask_li.length; i++) {
            var browseVal = browseTask_li[i].querySelector(".searchBigInput").value;
            var browseCount = browseTask_li[i].querySelector(".minInput").value;
            if (browseVal == "" || browseCount == "") {
                tipBoxJ.msg({ title: "请完整填写任务类型", time: 1000, icon: 2 });
                window.location.href = "#storeTitleDiv"
                return false
            }
        }
    }
    if (beginTime == "" || beginTime == "null") {
        tipBoxJ.msg({ title: "请输入开始时间", time: 1000, icon: 2 });
        window.location.href = "#beginTime";
        return false
    }
    if (pointTime.checked == true) {
        for (var i = 0; i < pushTimerLi.length; i++) {
            var curTime = pushTimerLi[i].querySelectorAll("input[name=pushTimer]")[0].value;
            var curNum = pushTimerLi[i].querySelectorAll("input[name=pushCount]")[0].value;
            if (curTime == "" || curNum == "") {
                tipBoxJ.msg({ title: "指定时间推送信息请填写完整", time: 1000, icon: 2 });
                window.location.hash = "#pushTimerLi[0]";
                return false;
            }
        }
    }
    if (otherSetList_li.length > 0) {//千人千面
        if (planId == "taobao") {
            if (document.getElementById("tblm000").checked == true) {//类目
                var typeListDetails = document.getElementById("Category").querySelectorAll("input[type=checkbox]");
                var tblm = 0;
                for (var i = 0; i < typeListDetails.length; i++) {
                    if (typeListDetails[i].checked == false) {
                        tblm++;
                    }
                }
                if (tblm == typeListDetails.length) {
                    tipBoxJ.msg({ title: "至少选择一项类目信息", time: 1000, icon: 2 });
                    window.location.hash = "#pointTime";
                    return false;
                }
            }
        }
        if (document.getElementById("AreaRange").checked == true) {
            var regionListDetails = document.getElementById("areaRange").querySelectorAll("input[type=checkbox]");
            var region = 0;
            for (var i = 0; i < regionListDetails.length; i++) {
                if (regionListDetails[i].checked == false) {
                    region++;
                }
            }
            if (region == regionListDetails.length) {
                tipBoxJ.msg({ title: "至少选择一项地域信息", time: 1000, icon: 2 });
                window.location.hash = "#rewardMoney";
                return false;
            }
        }
    }
    if (assignDay.checked) {
        if (refundTimes == "" || refundTimes == "null") {
            tipBoxJ.msg({ title: "请输入退款时间", time: 1000, icon: 2 });
            window.location.href = "#refundTimes";
            return false;
        } else {
            if (GetDateDiff(beginTime, refundTimes, "second") > 3*24*3600) {
                tipBoxJ.msg({ title: "指定退款时间不能超过3天", time: 1000, icon: 2 });
                //document.getElementById("refundTimes").value = "";
                return false;
            }
        }
    }
    if (refundType_select.value == "----请选择----") {
        tipBoxJ.msg({
            title: "请选择退款类型",
            time: 1000,
            icon: 2
        })
        return false;
    }
    return true;
}
//跳转至支付页面 
function goToPayment() {
    if (!isRequired()) {
        return false
    }
    document.getElementById("editTaskInfo").style.display = "none";
    document.getElementById("paymentCost").style.display = "block";
    var lookStr = "";//浏览任务
    var lookTotalPrice = 0;//浏览总价格
    var lookTotalNum = 0;//浏览总数量
    var rewardMoney = document.getElementById("rewardMoney").value;
    var addCommitionStr = "";//加赏佣金
    var rewardTotalMoney = 0;
    var paymentStr = "";//总体支付费用行数
    var firstExamStr = "";//优先审核
    var additional = document.getElementById("additional");//优先审核
    var eaxmTotalMoney = 0;
    var keywordText = "";//搜索关键字的内容
    var keyStr = "";//关键字行
    var keyPrice = 0;//单行关键字价格
    var keyTotalPrice = 0;//单行关键字总金额
    var keywordNum = 0;//单行关键字数量
    var addTotalCost = 0;//附加费用总价格  任务类型 附加选项
    var extraStr = "";//附加
    var extraFeeStr = "";
    var addTaskCheckBox = "";//复选框
    var addStr = "";//附加费用总费用行
    var addServiceStr = "";//增值服务
    var totalPrice = "";//总计
    var totalPriceStr = '';//
    //退款
    var refundPrice = 0;//退款费用
    var refundStr = "";//退款费用行
    var refundTotalPrice = 0;//退款总费用
    var assignDay = document.getElementById("assignDay");//指定时间按钮
    var beginTime = document.getElementById("beginTime").value;
    var refundTime = document.getElementById("refundTimes").value;
    var browseLi = document.querySelectorAll(".browseLi");
    for (var i = 0; i < browseLi.length; i++) {
        lookNum = Number(browseLi[i].querySelectorAll(".minInput")[0].value);
        lookTotalNum += lookNum;
        lookTotalPrice = (lookTotalNum * 3).toFixed(2);
        lookStr = '<tr><td>退款任务</td><td>3元/单</td><td>' + lookTotalNum + '</td><td>' + lookTotalPrice + '</td></tr>';
    }
    //判断是否选择了任务类型的附加                                                                                                                
    for (var j = 0; j < browseLi.length; j++) {
        keywordText = browseLi[j].querySelectorAll(".searchBigInput")[0].value;
        keywordNum = browseLi[j].querySelectorAll(".minInput")[0].value;
        addTaskCheckBox = browseLi[j].querySelectorAll(".addTask");//复选框
        for (var k = 0; k < addTaskCheckBox.length; k++) {
            if (addTaskCheckBox[k].checked) {
                keyPrice += Number(addTaskCheckBox[k].getAttribute("data-price"));
                extraStr += addTaskCheckBox[k].value + '、';
            }
        }
        extraStr = extraStr.substring(0, extraStr.length - 1);
        if (extraStr == "" || extraStr == "null") {
            extraFeeStr = "(无附加要求)"
        } else {
            extraFeeStr = '(' + extraStr + ')';
        }
        keyTotalPrice = (keyPrice * keywordNum).toFixed(2);
        addTotalCost += Number(keyTotalPrice);
        extraStr = '';
        keyPrice = 0;
        keyStr += '<tr><td>关键字' + (j + 1) + '</td><td>' + keywordText + extraFeeStr + '</td><td>' + keywordNum + '</td><td>' + keyTotalPrice + '</td></tr>';
    }

    if (rewardMoney == "" || rewardMoney == "null") {
        addCommitionStr = "";
    } else {
        rewardTotalMoney = (Number(rewardMoney) * lookTotalNum).toFixed(2);
        addCommitionStr = '<tr><td>加赏佣金</td><td>' + rewardMoney + '元/单</td><td>' + lookTotalNum + '</td><td>' + rewardTotalMoney + '</td></tr>'
    }
    //优先审核
    if (additional.checked) {
        eaxmTotalMoney = (Number(lookTotalNum) * 0.05).toFixed(2);
        firstExamStr = '<tr><td>优先审核</td><td>0.05元/单</td><td>' + lookTotalNum + '</td><td>' + eaxmTotalMoney + '</td></tr>'
    } else {
        firstExamStr = "";
    }

    //指定退款时间 
    if (assignDay.checked == true) {
        if (refundTime) {
            var time = GetDateDiff(beginTime, refundTime, "day");
            if (time < 1) {
                refundPrice += 1;
                refundTotalPrice = (Number(refundPrice) * lookTotalNum).toFixed(2);
                refundStr = '<tr><td>指定退款</td><td>指定退款' + refundPrice + '元/单</td><td>' + lookTotalNum + '</td><td>' + refundTotalPrice + '</td></tr>'
            } else if (time >= 1 && time < 2) {
                refundPrice += 2;
                refundTotalPrice = (Number(refundPrice) * lookTotalNum).toFixed(2);
                refundStr = '<tr><td>指定退款</td><td>超过24小时' + refundPrice + '元/单</td><td>' + lookTotalNum + '</td><td>' + refundTotalPrice + '</td></tr>'
            } else if (time >= 2 && time < 3) {
                refundPrice += 3;
                refundTotalPrice = (Number(refundPrice) * lookTotalNum).toFixed(2);
                refundStr = '<tr><td>指定退款</td><td>超过48小时' + refundPrice + '元/单</td><td>' + lookTotalNum + '</td><td>' + refundTotalPrice + '</td></tr>'
            }
            else if (time >= 3) {
                refundPrice += 4;
                refundTotalPrice = (Number(refundPrice) * lookTotalNum).toFixed(2);
                refundStr = '<tr><td>指定退款</td><td>72小时' + refundPrice + '元/单</td><td>' + lookTotalNum + '</td><td>' + refundTotalPrice + '</td></tr>'
            }
        } else {
            refundPrice += 1;
            refundTotalPrice = (Number(refundPrice) * lookTotalNum).toFixed(2);
            refundStr = '<tr><td>指定退款</td><td>指定退款' + refundPrice + '元/单</td><td>' + lookTotalNum + '</td><td>' + refundTotalPrice + '</td></tr>'
        }
        
    } else {
        refundStr = "";
    }
    //-----------增值服务------- 
    //#region
    var planId = GetQueryString("PLANID");
    var addServiceDetails = "";//增值服务详情
    var otherSetList = document.getElementById("otherSetList");//千人千面ul
    var otherSetList_li = otherSetList.getElementsByTagName("li");//li列表
    var addServiceTotalPrice = 0;//增值服务总金额
    var allTaskCount = lookTotalNum;
    if (otherSetList_li.length > 0) {
        if (planId == "taobao") {//淘宝
            var huabei = document.getElementById("tbhb000");
            var classList = document.getElementById("tblm000");
            var age = document.getElementById("tbln000");
            if (huabei.checked == true) {
                addServiceDetails += '<div>花呗号:2元/单</div>';
                addServiceTotalPrice += Number(Number(2 * allTaskCount).toFixed(2));
            }
            if (classList.checked == true) {
                addServiceDetails += '<div>类目:0.5元/单</div>';
                addServiceTotalPrice += Number(Number(0.5 * allTaskCount).toFixed(2));
            }
            if (age.checked == true) {
                addServiceDetails += '<div>年龄:0.5元/单</div>';
                addServiceTotalPrice += Number(Number(0.5 * allTaskCount).toFixed(2));
            }
        } else {
            var baitiao = document.getElementById("jdbt000");
            var age = document.getElementById("jdln000");
            if (baitiao.checked == true) {
                addServiceDetails += '<div>白条号:2元/单</div>';
                addServiceTotalPrice += Number(Number(2 * allTaskCount).toFixed(2));
            }
            if (age.checked == true) {
                addServiceDetails += '<div>年龄:0.5元/单</div>';
                addServiceTotalPrice += Number(Number(0.5 * allTaskCount).toFixed(2));
            }
        }
        var sex = document.getElementById("Sex");
        var grade = document.getElementById("grade");
        var AreaRange = document.getElementById("AreaRange");
        if (sex.checked == true) {
            addServiceDetails += '<div>性别限制:1元/单</div>';
            addServiceTotalPrice += Number(allTaskCount);
        }
        if (grade.checked == true) {
            addServiceDetails += '<div>买号等级限制:1元/单</div>';
            addServiceTotalPrice += Number(allTaskCount);
        }
        if (AreaRange.checked == true) {
            addServiceDetails += '<div>地域限制:1元/单</div>';
            addServiceTotalPrice += Number(allTaskCount);
        }
    }
    var checkbox_checked = otherSetList.querySelectorAll("input[type=checkbox]");//增值服务所有复选框
    var checked_num = 0;
    for (var c = 0; c < checkbox_checked.length; c++) {
        if (checkbox_checked[c].checked == true) {
            checked_num++;
        }
    }
    if (firstExamStr.checked == false && checked_num == 0) {
        addServiceStr = "";
    } else {
        addServiceStr = '<tr><td>增值服务</td>'
            + '<td>' + addServiceDetails + '</td>'
            + '<td>' + allTaskCount + '</td>'
            + '<td>' + addServiceTotalPrice.toFixed(2) + '</td>'
            + '</tr>';
    }
    addStr = '<tr style="height:40px;line-height:40px"><td>附加费用总价格</td><td colspan="3">' + Number(addTotalCost).toFixed(2) + '</td></tr>';
    totalPrice = Number(lookTotalPrice) + Number(eaxmTotalMoney) + Number(addServiceTotalPrice) + Number(addTotalCost) + Number(rewardTotalMoney) + Number(refundTotalPrice);
    totalPriceStr = '<tr><td>总计（元）</td><td colspan="3">' + (totalPrice).toFixed(2) + '</td></tr>';
    var BtnStr = '<tr><td colspan="4" style="border:none;"><div style="margin:15px;text-align:center;">'
        + '<input type="button" name="preBtn" value="上一步" class="stepInput" onclick="backToEditTask()" />'
        + '<input type="button" name="nextBtn" value="确定支付" data-value="' + totalPrice.toFixed(2) + '" class="stepInput" style="background-color:#aa0000;" onclick="creatRefundTask(this)" /></div></td ></tr > ';
    paymentStr = lookStr + refundStr + addCommitionStr + firstExamStr + keyStr + addServiceStr + addStr + totalPriceStr;

    document.getElementById("costDetailBody").innerHTML = paymentStr;
    document.getElementById("costDetailFoot").innerHTML = BtnStr;
    //#endregion
}
//返回填写任务界面
function backToEditTask() {
    document.getElementById("paymentCost").style.display = "none";
    document.getElementById("editTaskInfo").style.display = "block";
}

//创建退款任务
function creatRefundTask(_this) {
    var totalPrePay = _this.getAttribute("data-value");
    var allPriceNum = Number(totalPrePay);
    var recharge = sessionStorage.getItem("sRecharge_hidden");//当前本金
    var rechargeNum = Number(recharge);
    var str = '<div class="instantRecharge"><div style="margin-bottom: 15px;"><label class="rechargeTitile" > 充值金额</label>'
        + '<input type="number" max="50000" min="0.01" step="0.01" value="1.00" id="txtRecharge" class="txtRecharge" onkeyup="clearNoNum(this)" /></div>'
        + '<label class="rechargeTip">充值时请核对充值金额，以免造成不便！</label>'
        + '<div style="margin:12px;">'
        + '<label class="payType_label"><input style="vertical-align: middle;margin-bottom: 6px;" type="radio" class="radio" name="payType" value="0" onclick="chooseOne(this)" / checked>支付宝</label>'
        + '<label  class="payType_label"><input style="vertical-align: middle;margin-bottom: 6px;" type="radio" class="radio" name="payType_weixin" value="1" onclick="chooseOne(this)" disabled/>微信(待开通)</label></div>'
        + '<div style="position: relative"><input type="button" class="btnInstantRecharge" value="充值" class="btnRechr" onclick="recharge()" /></div>'
        + '<div id="imgAliQrCodeWrap">'
        + '<div id="ImgQrCode" class="imgQrCode" style="width: 200px; height: 200px; margin: 0 auto; padding: 10px;"></div></div></div>';
    if (allPriceNum > rechargeNum) {
        tipBoxJ.prompt({
            title: '提示',
            onConfirm: function (value) {
                tipBoxJ.close();
                tipBoxJ.bootBox({
                    area: ['380', '400'],
                    content: str,
                    onCancel: function () {
                        var recharge = document.getElementById("recharge");
                        var commission = document.getElementById("commission");
                        var data = {
                            ShowBind: false
                        }
                        SubmitData("/api/server/GetServerInfo", "POST", data, true, function (e) {
                            if (e != null) {
                                var res = JSON.parse(e);
                                var data = res.rData.UserInfo;
                                if (res.rCode == "0000") {
                                    var _recharge = data.Recharge;
                                    var _commission = data.Commission;
                                    recharge.innerHTML = _recharge;
                                    commission.innerHTML = _commission;
                                    sessionStorage.setItem("sRecharge_hidden", _recharge);
                                }
                                else if (res.rCode == "0001" || res.rCode == "0002") {
                                    tipBoxJ.msg({ title: res.rMsg, time: 1000, icon: 2 });
                                } else {
                                    tipBoxJ.msg({ title: res.rMsg, time: 1000, icon: 2 });
                                    tipBoxJ.msg({ title: res.rMsg, time: 1000, icon: 2 });
                                }
                            }
                        }, function (readyState, Status) { });
                        document.getElementById("payPrompt").style.display = "block";
                    }
                });
            }
        });
        document.querySelectorAll(".tipBoxPrompt_content")[0].innerHTML = "您的余额不足,请及时充值!";
        document.getElementById("tipBoxbody").style.width = "300px";
        document.querySelectorAll(".tipBoxPrompt_content")[0].style.fontSize = "13px";
        document.querySelectorAll(".tipBoxPrompt_content")[0].style.color = "#4c5260";
        document.querySelectorAll(".tipBoxPrompt-btn1")[0].style.background = "#aa0000";
        document.querySelectorAll(".tipBoxPrompt-btn1")[0].style.borderColor = "#aa0000";
        document.querySelectorAll(".tipBoxPrompt-btn1")[0].style.fontSize = "14px";
        document.querySelectorAll(".tipBoxPrompt-cancel")[0].style.fontSize = "14px";
        return false;
    }


    //1.主商品信息数据
    //#region
    var MainGoodsInfo = new Object();
    var goodsName = (document.getElementById("goodsName").value).trim();
    var goodsUrl = (document.getElementById("goodsUrl").value).trim();
    var goodsPrice = document.getElementById("goodsPrice").value;
    var goodsDisplayPrice = document.getElementById("goodsDisplayPrice").value;
    var goodsCount = document.getElementById("goodsCount").value;
    var postagePrice = document.getElementById("postagePrice").value;
    var skuValue = (document.getElementById("skuValue").value).trim();
    var imgUpload = document.getElementById("imgList").querySelectorAll(".imgBack");
    var mainImg = document.getElementById("imgList").querySelectorAll(".imgUploadStyle");//上传的图片
    var attachImgUpload = document.getElementById("attachImg").querySelectorAll(".imgBack");
    var attachImg = document.getElementById("attachImg").querySelectorAll(".imgUploadStyle");
    var anotherDay = document.getElementById("anotherDay");//次日退款
    var assignDay = document.getElementById("assignDay");//指定退款时间
    var date = document.getElementById("beginTime").value;
    var refundTime = document.getElementById("refundTimes").value;
    var refundType_select = document.getElementById("refundType_select");
    var option = refundType_select.querySelectorAll("option");
    var refundType = "";//退款类型
    var orderType = "";//指定退款
    var orderTime = "";//指定退款时间
    var goodsImg = "";//主商品图片
    var otherImg = "";//附加图片
    var otherContent = (document.getElementById("remarkArea").value).trim();//备注
    var planID = GetQueryString("PLANID");
    var shopID = GetQueryString("SHOPID");
    var ttID = GetQueryString("TTID");
    var mID = GetQueryString("MID");
    if ((goodsUrl.indexOf("http://") == -1) && (goodsUrl.indexOf("https://") == -1)) {
        goodsUrl = "http://" + goodsUrl;
    }
    if (imgUpload.length < 1) {
        goodsImg = "";
    } else {
        for (var i = 0; i < mainImg.length; i++) {
            if (i < mainImg.length - 1) {
                goodsImg += mainImg[i].src + ';';
            } else {
                goodsImg += mainImg[i].src;
            }
        }
    }
    if (attachImgUpload.length < 1) {
        otherImg = "";
    } else {
        for (var i = 0; i < attachImg.length; i++) {
            if (i < attachImg.length - 1) {
                otherImg += attachImg[i].src + ';';
            } else {
                otherImg += attachImg[i].src;
            }
        }
    }
    if (anotherDay.checked) {
        orderType = anotherDay.value;
        orderTime = addDate(date, 1);
    } else if (assignDay.checked) {
        orderType = assignDay.value;
        orderTime = refundTime;
    } else {
        orderType = null;
        orderTime = null;
    }
    for (var i = 0; i < option.length; i++) {
        if (refundType_select.value == "----请选择----") {
            refundType = "";
        } else {
            if (option[i].selected == true) {
                refundType = option[i].value;
            }
        }
    }
    MainGoodsInfo = {
        GoodsName: goodsName,
        GoodsUrl: goodsUrl,
        GoodsPrice: goodsPrice,
        GoodsDisplayPrice: goodsDisplayPrice,
        GoodsCount: goodsCount,
        PostagePrice: postagePrice,
        SkuValue: skuValue,
        GoodsImg: goodsImg,
        OtherContent: otherContent,
        OrderType: orderType,
        OrderTime: orderTime,
        OtherImg: otherImg,
        RefundType: refundType,
        PlanID: planID,
        ShopID: shopID,
        TTID: ttID,
        Mid: mID
    }


    //#endregion

    //2.搜索商品条件    排序方式  折扣与服务  商品所在地  订单留言  价格区间
    //#region
    var SearchCondition = new Object();
    var goodSortRadio = document.getElementsByName("GoodsSort");//排序方式
    var rangeInput = document.querySelectorAll(".rangeInput");//价格区间  
    var address_select = document.getElementById("address_select");//城市
    var discountInnerDiv = document.getElementById("discountInnerDiv");
    var discount_checkbox = discountInnerDiv.getElementsByTagName("input");//服务复选框
    var orderMsg = replaceEnter(document.getElementById("orderMessage").value).trim();//订单留言
    var goodsSort = "";
    var goodsPriceRegion = "";
    var goodsErea = "";
    var goodsDiscount = "";
    for (var i = 0; i < goodSortRadio.length; i++) {
        if (goodSortRadio[i].checked == true) {
            goodsSort = goodSortRadio[i].value;
        }
    }
    for (var i = 0; i < rangeInput.length; i++) {//价格区间
        if (i < rangeInput.length - 1) {
            goodsPriceRegion += rangeInput[i].value + '-';
        } else {
            goodsPriceRegion += rangeInput[i].value;
        }
    }
    for (var i = 0; i < address_select.options.length; i++) {
        if (address_select.options[i].selected) {
            goodsErea = address_select.options[i].innerText;
        }
    }
    for (var i = 0; i < discount_checkbox.length; i++) {
        if (discount_checkbox[i].checked == true) {
            goodsDiscount += discount_checkbox[i].value + ';';
        }
    }
    if (goodsPriceRegion == "-") {
        goodsPriceRegion = null;
    }
    goodsDiscount = goodsDiscount.substring(0, goodsDiscount.length - 1);
    SearchCondition = {
        GoodsSort: goodsSort,
        GoodsPriceRegion: goodsPriceRegion,
        GoodsErea: goodsErea,
        GoodsDiscount: goodsDiscount,
        OrderMsg: orderMsg
    };
    //#endregion

    //3.退款任务类型与数量  参数：推送时间  关键字列表 （关键字 数量  评价类型  收藏商品列表  收藏店铺列表 加购物车列表
    //#region
    var TaskDetails = new Object();
    TaskDetails.Items = [];
    var orderTime = document.getElementById("beginTime").value;
    var EvaluateType = document.getElementById("browseCheckBox").value;//类型 ---退款任务
    var GoodsKeywordsArray = [];    //商品关键字数组
    var TaskCountArray = [];        //商品数量数组
    var CollectionGoodsArray = [];  //收藏商品数组
    var CollectionShopArray = [];   //店铺数组
    var ShoppingCartArray = [];     //加购物车数组
    var GoodsKeys = document.querySelector(".taskListBlock").querySelectorAll("input[name=GoodsKeywords]");//关键字
    var BrowseNum = document.querySelector(".taskListBlock").querySelectorAll("input[name=TaskCount]");//数量
    var CollectGoods = document.querySelector(".taskListBlock").querySelectorAll("input[name=CollectionGoods]");//收藏商品
    var CollectShop = document.querySelector(".taskListBlock").querySelectorAll("input[name=CollectionShop]");//收藏店铺
    var ShopCart = document.querySelector(".taskListBlock").querySelectorAll("input[name=ShoppingCart]");//加购物车

    for (var k = 0; k < GoodsKeys.length; k++) {
        GoodsKeywordsArray.push(GoodsKeys[k].value.trim());
    }
    for (var n = 0; n < BrowseNum.length; n++) {
        TaskCountArray.push(BrowseNum[n].value);
    }
    for (var g = 0; g < CollectGoods.length; g++) {
        if (CollectGoods[g].checked == true) {
            CollectionGoodsArray.push(true);
        } else {
            CollectionGoodsArray.push(false);
        }
    }
    for (var s = 0; s < CollectShop.length; s++) {
        if (CollectShop[s].checked == true) {
            CollectionShopArray.push(true);
        } else {
            CollectionShopArray.push(false);
        }
    }
    for (var c = 0; c < ShopCart.length; c++) {
        if (ShopCart[c].checked == true) {
            ShoppingCartArray.push(true);
        } else {
            ShoppingCartArray.push(false);
        }
    }
    var browse_JSON = "";
    for (var i = 0; i < GoodsKeywordsArray.length; i++) {
        browse_JSON += '{"GoodsKeywords":"' + GoodsKeywordsArray[i] + '","TaskCount":"' + TaskCountArray[i] + '","EvaluateType":"' + EvaluateType + '","CollectionGoods":' + CollectionGoodsArray[i] + ',"CollectionShop":' + CollectionShopArray[i] + ',"ShoppingCart":' + ShoppingCartArray[i] + ',"EvaluateContent":' + null + ',"EvaluateFile":' + null + '}' + ',';
    }
    browse_JSON = '[' + browse_JSON.substring(0, browse_JSON.length - 1) + ']';
    TaskDetails.Items = JSON.parse(browse_JSON);//转为json对象
    TaskDetails.PushTime = orderTime;
    //#endregion

    //4.推送设置 参数 推送时间  推送数量   判断类型   时间点与数量的数据
    //#region
    var PushTimeTable = new Object();
    var pushTime_JSON = "";
    var pushType = document.getElementById("pushSetDiv").querySelectorAll("input[name=pushTimeChoose]");//推送类型复选框
    var PushTimeArray = [];//推送时间数组
    var PushCountArray = [];//推送数量数组
    var pushTime = document.getElementById("pushTimerList").querySelectorAll("input[name=pushTimer]");
    var pushNum = document.getElementById("pushTimerList").querySelectorAll("input[name=pushCount]");
    if (pushType[0].checked == true) {
        pushTime_JSON = '{"PushTime":' + null + ',"PushCount":' + null + '}';
        PushTimeTable = JSON.parse(pushTime_JSON);
    }
    if (pushType[1].checked == true) {//时间点
        for (var t = 0; t < pushTime.length; t++) {
            PushTimeArray.push(pushTime[t].value);
        }
        for (var n = 0; n < pushNum.length; n++) {
            PushCountArray.push(pushNum[n].value);
        }
        for (var j = 0; j < PushTimeArray.length; j++) {
            pushTime_JSON += '{"PushTime":"' + PushTimeArray[j] + '","PushCount":"' + PushCountArray[j] + '"' + '}' + ',';
        }
        pushTime_JSON = '[' + pushTime_JSON.substring(0, pushTime_JSON.length - 1) + ']';
        PushTimeTable = JSON.parse(pushTime_JSON);

    }
    //#endregion
    //5.增值服务  参数    赏金  优先审核  等级  地域  性别    其他  -- 服务编号  服务名称   服务内容或详情
    //#region
    var IncrementService = new Object();
    var sreward = document.getElementById("rewardMoney").value;
    var priAudit = document.getElementById("additional");
    if (priAudit.checked == true) {
        priAudit = true;
    } else {
        priAudit = false;
    }
    IncrementService = {
        SReward: sreward,
        PriorityAudit: priAudit
    }
    //#endregion

    //6. 增值服务 千人千面  参数  花呗  等级  性别 地区 年龄  (指定时间推送)
    //#region
    var planid = GetQueryString("PLANID");//平台id
    var otherSetList = document.getElementById("otherSetList");//千人千面ul
    var otherSetList_li = otherSetList.getElementsByTagName("li");
    if (otherSetList_li.length > 0) {
        var incrementService_JSON = "";
        var servicename = "";
        if (planid == "taobao") {//找到每一个被选中的 
            var huabei = document.getElementById("tbhb000");
            var list = document.getElementById("tblm000");
            var age = document.getElementById("tbln000");
            if (huabei.checked == true) {
                servicename = String(huabei.parentNode.children[1].innerText);//花呗号
                incrementService_JSON += '{"ServiceID":"' + huabei.value + '","ServiceName":"' + servicename + '","ServiceContent":null' + '}' + ',';
                servicename = "";
            } else {
                incrementService_JSON += "";
            }
            if (list.checked == true) {//类目
                servicename = String(list.parentNode.children[1].innerText);
                var list_details = document.getElementById("Category").querySelectorAll("input[type=checkbox]");
                var list_detailsStr = "";
                for (var n = 0; n < list_details.length; n++) {
                    if (list_details[n].checked == true) {
                        list_detailsStr += list_details[n].value + '|';
                    }
                }
                list_detailsStr = list_detailsStr.substring(0, list_detailsStr.length - 1);
                incrementService_JSON += '{"ServiceID":"' + list.value + '","ServiceName":"' + servicename + '","ServiceContent":"' + list_detailsStr + '"' + '}' + ',';
                servicename = "";
                list_detailsStr = "";
            } else {
                incrementService_JSON += "";
            }
            if (age.checked == true) {
                servicename = String(age.parentNode.children[1].innerText);
                var age_details = document.getElementById("age").querySelectorAll("input[type=radio]");
                var age_detailsStr = "";
                for (var o = 0; o < age_details.length; o++) {
                    if (age_details[o].checked == true) {
                        age_detailsStr = age_details[o].value;
                    }
                }
                incrementService_JSON += '{"ServiceID":"' + age.value + '","ServiceName":"' + servicename + '","ServiceContent":"' + age_detailsStr + '"' + '}' + ',';
                servicename = "";
                age_detailsStr = "";
            } else {
                incrementService_JSON += "";
            }
            if (grade.checked == true) {
                IncrementService.LevelRequire = 251;
            } else {
                IncrementService.LevelRequire = null;
            }
        }
        else {
            var baitiao = document.getElementById("jdbt000");
            var age = document.getElementById("jdln000");
            if (baitiao.checked == true) {
                servicename = String(baitiao.parentNode.children[1].innerText);
                incrementService_JSON += '{"ServiceID":"' + baitiao.value + '","ServiceName":"' + servicename + '","ServiceContent":null' + '}' + ',';
                servicename = "";
            } else {
                incrementService_JSON += "";
            }
            if (age.checked == true) {
                servicename = String(age.parentNode.children[1].innerText);
                var age_details = document.getElementById("age").querySelectorAll("input[type=radio]");
                var age_detailsStr = "";
                for (var o = 0; o < age_details.length; o++) {
                    if (age_details[o].checked == true) {
                        age_detailsStr = age_details[o].value;
                    }
                }
                incrementService_JSON += '{"ServiceID":"' + age.value + '","ServiceName":"' + servicename + '","ServiceContent":"' + age_detailsStr + '"' + '}' + ',';
            } else {
                incrementService_JSON += "";
            }
            if (grade.checked == true) {
                IncrementService.LevelRequire = 4;
            } else {
                IncrementService.LevelRequire = null;
            }
        }
        var sex = document.getElementById("Sex");
        var areaCheckbox = document.getElementById("AreaRange");
        if (sex.checked == true) {
            var sex_details = document.getElementById("sex").querySelectorAll("input[type=radio]");
            var sex_detailsStr = "";
            for (var p = 0; p < sex_details.length; p++) {
                if (sex_details[p].checked == true) {
                    sex_detailsStr = sex_details[p].value;
                }
            }
            IncrementService.GenderRequire = sex_detailsStr;
        } else {
            IncrementService.GenderRequire = null;
        }
        if (areaCheckbox.checked == true) {
            var area_details = document.getElementById("areaRange").querySelectorAll("input[type=checkbox]");
            var area_detailsStr = "";
            for (var q = 0; q < area_details.length; q++) {
                if (area_details[q].checked == true) {
                    area_detailsStr += area_details[q].value + '|';
                }
            }
            area_detailsStr = area_detailsStr.substring(0, area_detailsStr.length - 1);
            IncrementService.RegionRequire = area_detailsStr;
        } else {
            IncrementService.RegionRequire = null;
        }
        incrementService_JSON = '[' + incrementService_JSON.substring(0, incrementService_JSON.length - 1) + ']';
        IncrementService.IncrementServices = JSON.parse(incrementService_JSON);
    } else {
        IncrementService.LevelRequire = null;
        IncrementService.RegionRequire = null;
        IncrementService.GenderRequire = null;
        IncrementService.IncrementServices = null;
    }
    //#endregion
    //7.附加商品  商品链接 商品名称  商品主图  商品成交价格 拍下商品数量 商品展示价格 商品附加属性 备注
    //#region
    var AttachGoods = new Object();
    var goodsUrlArr = [];//附属商品链接数组
    var goodsNameArr = [];//附属商品名字数组
    var goodsImgArr = [];//附属商品主图片数组
    var goodsPriceArr = [];//附属商品成交价格数组
    var goodCountArr = [];//附属商品单拍数量数组
    var goodsDisplayPrice = [];//附属商品展示价格数组
    var skuValueArr = [];//附属商品属性数组
    var postagePriceArr = [];//附属商品邮费数组
    var addProductList_li = document.getElementById("addProductList").querySelectorAll("li");
    if (addProductList_li.length > 0) {
        var addGoodsName = document.getElementById("addProductList").querySelectorAll(".goodsName");
        var addGoodsPrice = document.getElementById("addProductList").querySelectorAll(".goodsPrice");
        var addGoodsUrl = document.getElementById("addProductList").querySelectorAll(".goodsUrl");
        var addGoodsCount = document.getElementById("addProductList").querySelectorAll(".goodsCount");
        var addGoodsDisplayPrice = document.getElementById("addProductList").querySelectorAll(".goodsDisplayPrice")
        var addPostagePrice = document.getElementById("addProductList").querySelectorAll(".postagePrice");
        var addSkuValue = document.getElementById("addProductList").querySelectorAll(".skuValue");
        var addAttachImg = document.getElementById("addProductList").querySelectorAll(".imgBack");
        var addGoodsImgList = "";
        var attachImg_str = "";
        var addRemark = "";
        var addAttach_JSON = "";
        for (var i = 0; i < addGoodsName.length; i++) {
            goodsNameArr.push(addGoodsName[i].value.trim());
        }
        for (var i = 0; i < addGoodsPrice.length; i++) {
            goodsPriceArr.push(addGoodsPrice[i].value);
        }

        for (var i = 0; i < addGoodsUrl.length; i++) {
            if ((addGoodsUrl[i].value.trim().indexOf("http://") == -1) && (addGoodsUrl[i].value.trim().indexOf("https://") == -1)) {
                addGoodsUrl[i].value = "http://" + addGoodsUrl[i].value.trim();
            }
            goodsUrlArr.push(addGoodsUrl[i].value.trim());

        }
        for (var i = 0; i < addGoodsDisplayPrice.length; i++) {
            goodsDisplayPrice.push(addGoodsDisplayPrice[i].value);
        }
        for (var i = 0; i < addGoodsCount.length; i++) {
            goodCountArr.push(addGoodsCount[i].value);
        }
        for (var i = 0; i < addPostagePrice.length; i++) {
            postagePriceArr.push(addPostagePrice[i].value);
        }
        for (var i = 0; i < addSkuValue.length; i++) {
            skuValueArr.push(addSkuValue[i].value.trim());
        }
        for (var i = 0; i < addAttachImg.length; i++) {
            addGoodsImgList = addAttachImg[i].querySelectorAll(".imgUploadStyle");
            for (var j = 0; j < addGoodsImgList.length; j++) {
                attachImg_str += addGoodsImgList[j].src + ';';
            }
            attachImg_str = attachImg_str.substring(0, attachImg_str.length - 1);
            goodsImgArr.push(attachImg_str);
            attachImg_str = "";
        }
        for (var i = 0; i < goodsNameArr.length; i++) {
            addAttach_JSON += '{"GoodsName":"' + goodsNameArr[i] + '","GoodsUrl":"' + goodsUrlArr[i] + '","GoodsPrice":"' + goodsPriceArr[i] + '","GoodsDisplayPrice":"' + goodsDisplayPrice[i] + '","GoodsCount":"' + goodCountArr[i] + '","SkuValue":"' + skuValueArr[i] + '","GoodsImg":"' + goodsImgArr[i] + '","Remark":""' + '}' + ',';
        }
        addAttach_JSON = '[' + addAttach_JSON.substring(0, addAttach_JSON.length - 1) + ']';
        AttachGoods = JSON.parse(addAttach_JSON);
    } else {
        AttachGoods = {
            GoodsUrl: null,
            GoodsName: null,
            GoodsPrice: null,
            GoodsCount: null,
            GoodsDisplayPrice: null,
            SkuValue: null,
            GoodsImg: null,
            Remark: null
        }
    }

    //#endregion
    var data = {
        MainGoodsInfo: MainGoodsInfo,
        SearchCondition: SearchCondition,
        TaskDetails: TaskDetails,
        PushTimeTable: PushTimeTable,
        IncrementService: IncrementService,
        AttachGoods: AttachGoods
    };
    tipBoxJ.loadNew();
    SubmitData("/api/server/createRefundTask", "POST", data, true, function (e) {
        tipBoxJ.closeNew();
        if (e != null) {
            var res = JSON.parse(e);
            if (res.rCode == "0000") {
                document.getElementById("lastIcon").style.background = "#aa0000";
                tipBoxJ.msg({
                    title: res.rMsg, time: "2000", icon: 1, callBack: function () {
                        window.location.href = "/web/server/sCreateTask.aspx";
                    }
                });
            } else if (res.rCode == "0001" || res.rCode == "0002") {
                tipBoxJ.msg({
                    title: res.rMsg, time: "1000", icon: 2, callBack: function () {
                        window.location.href = "/web/server/sLogin.aspx";
                    }
                });
            } else {
                tipBoxJ.msg({
                    title: res.rMsg, time: "1000", icon: 2
                });
            }
        }
    }, function (readystate, status) { });

}
//充值
function recharge() {
    var txtRecharge = document.getElementById("txtRecharge").value;//金额
    var chargeData = {
        dAmount: txtRecharge
    };
    if (txtRecharge == "" || txtRecharge == null) {
        tipBoxJ.msg({ title: "请输入充值金额", time: 1000, icon: 2 });
        return;
    }
    if (txtRecharge < 0.01 || txtRecharge > 50000) {
        txtRecharge = "";
        tipBoxJ.msg({ title: "充值金额范围0.01-50000", time: 1000, icon: 2 });
        return;
    }
    tipBoxJ.loadNew();
    SubmitData("/api/server/alipayRecharge", "POST", chargeData, true, function (e) {
        if (e != "null") {
            tipBoxJ.closeNew();
            var res = JSON.parse(e);
            if (res.rCode == "0000") {

                var data = res.rData.qrCode;
                newQRCode("ImgQrCode", data)
            } else if (res.rCode == "0001" || resd.rCode == "0002") {
                tipBoxJ.msg({ title: res.rMsg, time: "1000", icon: 2 });
                txtRecharge.innerHTML = "";
            } else {
                tipBoxJ.msg({ title: res.rMsg, time: "1000", icon: 2 });
                txtRecharge.innerHTML = "";
            }
        }
    }, function (readyState, Status) {

    })
}
//二维码
function newQRCode(item, txt) {
    document.getElementById(item).innerHTML = '';//清屏
    var qrcode = new QRCode(item, {
        text: txt,
        width: 200,
        height: 200,
        colorDark: '#000000',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.H
    });
}
//更新本金
function updataRecharge() {
    var recharge = document.getElementById("recharge");
    var commission = document.getElementById("commission");
    var data = {
        ShowBind: false
    }
    SubmitData("/api/server/GetServerInfo", "POST", data, true, function (e) {
        if (e != null) {
            var res = JSON.parse(e);
            var data = res.rData.UserInfo;
            if (res.rCode == "0000") {
                var _recharge = data.Recharge;
                var _commission = data.Commission;
                recharge.innerHTML = _recharge;
                commission.innerHTML = _commission;
                sessionStorage.setItem("_recharge", _recharge);
                tipBoxJ.msg({ title: "更新成功", time: 1000, icon: 1 });
            }
            else if (res.rCode == "0001" || res.rCode == "0002") {
                tipBoxJ.msg({ title: res.rMsg, time: 1000, icon: 2 });
            } else {
                tipBoxJ.msg({ title: res.rMsg, time: 1000, icon: 2 });
            }
        }
    }, function (readyState, Status) { });

}
//上一步
function goBack() {
    window.location.href = "/web/server/sCreateTask.aspx";
}
//数量限制 推送
function countLimit(_this) {
    var totalTaskCount = Number(document.getElementById("totalTaskCount").innerText);
    var browseCheckBox = document.getElementById("browseCheckBox");
    var pushTimerList_li = document.getElementById("pushTimerList").querySelectorAll("li");
    var num = 0;
    if (browseCheckBox.checked) {//总的填写的数量 
        for (var i = 0; i < pushTimerList_li.length; i++) {
            var browseCount = pushTimerList_li[i].querySelectorAll(".middleInput")[1].value;
            num += Number(browseCount);
        }
        if (num >= totalTaskCount) {
            document.getElementById("addTaskBtn").onclick = null;

        } else {
            document.getElementById("addTaskBtn").onclick = function () {
                addMorePushSetTime();
            };
        }
        if (num > totalTaskCount) {
            tipBoxJ.msg({
                title: "请重新输入数量",
                time: 1000,
                icon: 2
            })
            _this.value = "";
        }
    }
}
//选择退款类型
function selectRefundType() {
    var plan_id = GetQueryString("PLANID");
    var typeStr = '';
    if (plan_id == "jd") {
        typeStr = '<option selected>----请选择----</option><option value="商品无货">商品无货</option><option value="不想要了">不想要了</option><option value="发货时间问题">发货时间问题</option>'
            + '<option value="商品信息填写错误">商品信息填写错误</option> <option value="地址信息填写错误">地址信息填写错误</option>';
    } else if (plan_id == "taobao") {
        typeStr = '<option selected>----请选择----</option><option value="其他">其他</option><option value="缺货">缺货</option><option value="协商一致退款">协商一致退款</option>'
            + '<option value="未按约定时间发货">未按约定时间发货</option> <option value="拍错/多拍/不想要">拍错/多拍/不想要</option>';
    } else {
        typeStr = '<option value="其他" selected>其他</option>';
    }
    document.getElementById("refundType_select").innerHTML = typeStr;
}


//计算时间差
function GetDateDiff(startTime, endTime, diffType) {
    //将xxxx-xx-xx的时间格式，转换为 xxxx/xx/xx的格式 
    startTime = startTime.replace(/\-/g, "/");
    endTime = endTime.replace(/\-/g, "/");
    //将计算间隔类性字符转换为小写
    diffType = diffType.toLowerCase();
    var sTime = new Date(startTime); //开始时间
    var eTime = new Date(endTime); //结束时间
    //作为除数的数字
    var timeType = 1;
    switch (diffType) {
        case "second":
            timeType = 1000;
            break;
        case "minute":
            timeType = 1000 * 60;
            break;
        case "hour":
            timeType = 1000 * 3600;
            break;
        case "day":
            timeType = 1000 * 3600 * 24;
            break;
        default:
            break;
    }
    return parseInt((eTime.getTime() - sTime.getTime()) / parseInt(timeType));
}

//一键重发
function getTaskDetailsInfo() {
    var sTaskID = GetQueryString("STASKID");
    if (sTaskID == "" || sTaskID == "null") {
        return false;
    }
    var data = {
        STaskID: sTaskID
    };
    SubmitData("/api/server/getTaskInfo", "POST", data, true, function (e) {
        if (e != "null") {
            var res = JSON.parse(e);
            if (res.rCode == "0000") {
                var TaskInfo = res.rData.TaskInfo;
                var MainGoodsInfo = TaskInfo.MainGoodsInfo;
                var SearchCondition = TaskInfo.SearchCondition;
                var TaskDetails = TaskInfo.TaskDetails;
                var PushTimeTable = TaskInfo.PushTimeTable;
                var IncrementService = TaskInfo.IncrementService;
                var AttachGoods = TaskInfo.AttachGoods;
                var assignDay = document.getElementById("assignDay");
                var refundTimes = document.getElementById("refundTimes");
                var beginTime = document.getElementById("beginTime");
                var str1 = "";//商品主图片字段
                var str2 = "";//独家商品图片字段
                var orderType = MainGoodsInfo.OrderType;
                var imgListArr = MainGoodsInfo.GoodsImg.split(";");//主商品图片数组
                var otherImgArr = MainGoodsInfo.OtherImg.split(";"); //附加商品图片数组
                var options = document.getElementById("refundType_select").getElementsByTagName("option");
                document.getElementById("goodsName").value = MainGoodsInfo.GoodsName;
                document.getElementById("goodsUrl").value = MainGoodsInfo.GoodsUrl;
                document.getElementById("goodsPrice").value = MainGoodsInfo.GoodsPrice;;
                document.getElementById("goodsDisplayPrice").value = MainGoodsInfo.GoodsDisplayPrice;
                document.getElementById("goodsCount").value = MainGoodsInfo.GoodsCount;
                document.getElementById("postagePrice").value = MainGoodsInfo.PostagePrice;
                document.getElementById("skuValue").value = MainGoodsInfo.SkuValue;
                document.getElementById("remarkArea").value = MainGoodsInfo.OtherContent;
                totalMoney();
                //if (MainGoodsInfo.RefundType != "") {//退款类型
                //    for (var i = 0; i < options.length; i++) {
                //        if (options[i].value == MainGoodsInfo.RefundType) {
                //            options[i].selected = true;
                //            document.getElementById("refundType_select").value = MainGoodsInfo.RefundType;
                //        }
                //    }
                //}
                //主商品
                for (var i = 0; i < imgListArr.length; i++) {
                    if (imgListArr[i] != "") {
                        document.getElementById("goodImgBlock").innerHTML = "";
                        str1 += '<div class="imgBack" id="imgBack">'
                            + '<span class="removeIcon" id="removeIcon" onclick="removeImg(this)"><a class="removeInnerIcon">x</a></span >'
                            + '<img src = "' + imgListArr[i] + '" class="imgUploadStyle"></div>';
                    }
                }
                document.getElementById("goodImgBlock").innerHTML = str1;
                if (otherImgArr != "") {//附属商品图片
                    for (var i = 0; i < otherImgArr.length; i++) {
                        if (otherImgArr[i] != "") {
                            str2 += '<div class="imgBack" id="imgBack">'
                                + '<span class="removeIcon" id="removeIcon" onclick="removeImg(this)"><a class="removeInnerIcon">x</a></span >'
                                + '<img src = "' + otherImgArr[i] + '" class="imgUploadStyle"></div>';
                        }
                    }
                    document.getElementById("attachImg").innerHTML = str2;
                }
                //if (orderType == "31") {//退款时间
                //    assignDay.checked = true;
                //    document.getElementById("anotherDay").checked = false;
                //    var refundTime = MainGoodsInfo.OrderTime;//订单时间
                //    if (refundTime != "" && refundTime != null) {
                //        var refundTime1 = eval("new " + refundTime.substring(1, refundTime.length - 1));//
                //        refundTime = refundTime1.Format("yyyy-MM-dd");
                //        refundTimes.value = refundTime;
                //    }
                //} else if (orderType == "30") {
                //    document.getElementById("anotherDay").checked = true;
                //    assignDay.checked = false;
                //}
                var sortRadio = document.querySelectorAll("input[name=GoodsSort]");
                for (var i = 0; i < sortRadio.length; i++) {
                    if (sortRadio[i].value == SearchCondition.GoodsSort) {
                        sortRadio[i].checked = true;
                    }
                }
                var goodPriceInput = document.querySelectorAll(".rangeInput");
                var goodPriceArr = SearchCondition.GoodsPriceRegion.split("-");
                if (SearchCondition.GoodsPriceRegion != "") {
                    for (var i = 0; i < goodPriceArr.length; i++) {
                        goodPriceInput[i].value = goodPriceArr[i];
                    }
                }
                //商品所在地
                //var address_selects12 = document.getElementById("address_select");
                //var op = address_selects12.getElementsByTagName("option");
                //address_selects12.value = SearchCondition.GoodsErea;
                //for (var i = 0; i < op.length; i++) {
                //    if (op[i].innerText == SearchCondition.GoodsErea) {
                //        op[i].selected = true;
                //    }
                //}
             
                document.getElementById("orderMessage").value = SearchCondition.OrderMsg;
                var goodsDiscountCheckBox = document.getElementById("discountInnerDiv").getElementsByTagName("input");//折扣与服务
                var goodsDiscount = (SearchCondition.GoodsDiscount).split(";");
                for (var i = 0; i < goodsDiscountCheckBox.length; i++) {
                    for (var j = 0; j < goodsDiscount.length; j++) {
                        if (goodsDiscountCheckBox[i].value == goodsDiscount[j]) {
                            goodsDiscountCheckBox[i].checked = true;    
                        }
                    }
                }
                //附加商品 AttachGoods
                if (AttachGoods.length > 0) {
                    for (var i = 0; i < AttachGoods.length; i++) {
                        addMoreProductInfo();//添加商品 
                        var addProductList = document.getElementById("addProductList");
                        var goodsName = addProductList.querySelectorAll(".goodsName");
                        var goodsUrl = addProductList.querySelectorAll(".goodsUrl");
                        var goodsPrice = addProductList.querySelectorAll(".goodsPrice");
                        var goodsDisplayPrice = addProductList.querySelectorAll(".goodsDisplayPrice");
                        var goodsCount = addProductList.querySelectorAll(".goodsCount");
                        var skuValue = addProductList.querySelectorAll(".skuValue");
                        var goodsCount = addProductList.querySelectorAll(".goodsCount");
                        var addImgBack = addProductList.querySelectorAll(".addImgBack");//附加图片存放的div
                        var imgArr = "";
                        var str3 = "";
                        goodsName[i].value = AttachGoods[i].GoodsName;
                        goodsUrl[i].value = AttachGoods[i].GoodsUrl;
                        goodsPrice[i].value = AttachGoods[i].GoodsPrice;
                        goodsCount[i].value = AttachGoods[i].GoodsCount;
                        goodsDisplayPrice[i].value = AttachGoods[i].GoodsDisplayPrice;
                        skuValue[i].value = AttachGoods[i].SkuValue;
                        imgArr = AttachGoods[i].GoodsImg.split(";");
                        for (var j = 0; j < imgArr.length; j++) {
                            if (imgArr[i] != "") {
                                addImgBack[i].innerHTML = "";
                                str3 += '<div class="imgBack" id="imgBack">'
                                    + '<span class="removeIcon" id="removeIcon" onclick="removeImg(this)"><a class="removeInnerIcon">x</a></span >'
                                    + '<img src = "' + imgArr[j] + '" class="imgUploadStyle"></div>';
                            }
                        }
                        addImgBack[i].innerHTML = str3;

                    }
                    addTotalMoney();

                }
                //任务类型与数量
                var itemArr = TaskDetails.Items;
                if (itemArr.length > 0) {
                    if (itemArr.length > 1) {
                        for (var i = 0; i < itemArr.length - 1; i++) {
                            addMoreBrowseTask();
                        }
                    }
                    var curGoodsKeywords = document.querySelectorAll("input[name=GoodsKeywords]");//当前搜索关键字
                    var curTaskCount = document.querySelectorAll("input[name=TaskCount]");//当前搜索数量
                    var browseLi = document.getElementById("browseTaskList").querySelectorAll("li");
                    var curAttachCheckBox = "";

                    for (var i = 0; i < curGoodsKeywords.length; i++) {//搜索关键字
                        curGoodsKeywords[i].value = itemArr[i].GoodsKeywords;
                        curTaskCount[i].value = itemArr[i].TaskCount;
                        curAttachCheckBox = browseLi[i].querySelectorAll("input[type=checkbox]");
                        for (var j = 0; j < curAttachCheckBox.length; j++) {
                            curAttachCheckBox[0].checked = itemArr[i].CollectionGoods;
                            curAttachCheckBox[1].checked = itemArr[i].CollectionShop;
                            curAttachCheckBox[2].checked = itemArr[i].ShoppingCart;
                        }
                    }
                }

                //推送设置 PushTimeTable
                var pushTime = TaskDetails.PushTime;//订单时间
                //if (pushTime != null && pushTime != "") {
                //    var beginTime1 = eval("new " + pushTime.substring(1, pushTime.length - 1));
                //    pushTime = beginTime1.Format("yyyy-MM-dd");
                //    beginTime.value = pushTime;
                //}
                if (PushTimeTable.length > 0) {//推送时间
                    document.getElementById("pointTime").checked = true;
                    changePushWay(document.getElementById("pointTime"));
                    if (PushTimeTable.length > 1) {
                        for (var i = 0; i < PushTimeTable.length - 1; i++) {
                            addMorePushSetTime();
                        }

                    }
                    var timer = document.getElementById("pushTimerList").querySelectorAll("input[name=pushTimer]");
                    var count = document.getElementById("pushTimerList").querySelectorAll("input[name=pushCount]");
                    for (var i = 0; i < PushTimeTable.length; i++) {
                        timer[i].value = PushTimeTable[i].PushTime;
                        count[i].value = PushTimeTable[i].PushCount;
                    }
                    totalTaskNum();
                }
                //增值服务 IncrementService
                var incrementServices = IncrementService.IncrementServices;
                document.getElementById("rewardMoney").value = IncrementService.SReward;
                document.getElementById("additional").checked = IncrementService.PriorityAudit;
                var planID = GetQueryString("PLANID");
                if (incrementServices.length > 0) { 
                    showOtherSet();
                }
                for (var i = 0; i < incrementServices.length; i++) {
                    var serviceID = incrementServices[i].ServiceID;
                    var serviceContent = incrementServices[i].ServiceContent;
                    var levelRequire = IncrementService.LevelRequire;
                    if (planID == "taobao") {//淘宝
                        if (serviceID == "tbhb000") {//花呗
                            document.getElementById("tbhb000").checked = true;
                        } else if (serviceID == "tblm000") {//类目
                            document.getElementById("tblm000").checked = true;
                            openCategory(document.getElementById("tblm000"));
                            serviceContent = serviceContent.split("|");
                            var taobao_list = document.getElementById("Category").querySelectorAll("input[type=checkbox]");
                            for (j = 0; j < taobao_list.length; j++) {
                                for (var k = 0; k < serviceContent.length; k++) {
                                    if (taobao_list[j].value == serviceContent[k]) {
                                        taobao_list[j].checked = true;
                                    }
                                }
                            }
                        } else if (serviceID == "tbln000") {//年龄
                            document.getElementById("tbln000").checked = true;
                            openAge(document.getElementById("tbln000"));
                            var age_list = document.getElementById("age").querySelectorAll("input[type=radio]");
                            for (j = 0; j < age_list.length; j++) {
                                if (age_list[j].value == serviceContent) {
                                    age_list[j].checked = true;
                                }
                            }
                        }
                        if (levelRequire == 251) {//等级
                            document.getElementById("grade").checked = true;
                        }

                    } else {//京东
                        if (serviceID == "jdbt000") {//白条
                            document.getElementById("jdbt000").checked = true;
                        }
                        if (serviceID == "jdln000") {//年龄
                            document.getElementById("jdln000").checked = true;
                            openAge(document.getElementById("jdln000"));
                            var age_list = document.getElementById("age").querySelectorAll("input[name=age]");
                            for (j = 0; j < age_list.length; j++) {
                                if (age_list[j] == serviceContent) {
                                    age_list[j].checked = true;
                                }
                            }
                        }
                        if (levelRequire == 4) {//等级
                            document.getElementById("grade").checked = true;
                        }
                    }
                }
                var otherSetList = document.getElementById("otherSetList");//千人千面ul
                var otherSetting_li = otherSetList.getElementsByTagName("li");
                var genderRequire = IncrementService.GenderRequire;//性别
                var regionRequire = IncrementService.RegionRequire;//地域范围
                if (otherSetting_li.length > 0) {
                    if (genderRequire == "") {//性别
                        document.getElementById("Sex").checked = false;
                    } else {
                        document.getElementById("Sex").checked = true;
                        openSex(document.getElementById("Sex"));
                        var sexCheckbox = document.getElementById("sex").querySelectorAll("input[name=sex]");
                        for (var j = 0; j < sexCheckbox.length; j++) {
                            if (sexCheckbox[j].value == genderRequire) {
                                sexCheckbox[j].checked = true;
                            }
                        }
                    }
                    if (regionRequire == "" || regionRequire == "null") {//地域
                        document.getElementById("AreaRange").checked = false;
                    } else {
                        document.getElementById("AreaRange").checked = true;
                        regionRequireArr = regionRequire.split("|");
                        openAreaRange(document.getElementById("AreaRange"));
                        var areaCheckBox = document.getElementById("areaRange").querySelectorAll("input[type=checkbox]");
                        for (var j = 0; j < areaCheckBox.length; j++) {
                            for (var k = 0; k < regionRequireArr.length; k++) {
                                if (areaCheckBox[j].value == regionRequireArr[k]) {
                                    areaCheckBox[j].checked = true;
                                }
                            }

                        }
                    }
                }
            } else if (res.rCode == "0001" || res.rCode == "0002") {
                tipBoxJ.msg({
                    title: res.msg,
                    time: 1000,
                    icon: 2
                })
            } else {
                tipBoxJ.msg({
                    title: res.msg,
                    time: 1000,
                    icon: 2
                })
            }
        }
    }, function (readyState, Status) { })
}

//页面全部加载完后执行
document.ready(function () {
    showPlatformService();
    getProvince();
    selectRefundType();
    getTaskDetailsInfo();
})
document.ready = function () {}